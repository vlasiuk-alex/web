import React, {createElement} from 'react';
import ReactDOM from "react-dom";
import Render_login, {Work} from "./js/Login";
import axios from "axios";
import App from "./js/App";
import {WorkSignUp} from "./js/Sign_up";
import Render_SignUp from "./js/Sign_up";
import {WorkAddCourse} from "./js/Menu";
// import Menu from "/js/main";


  jest.mock('axios');

  describe('App', () => {
    it('alive',()=>{
      const div = document.createElement("div");
      ReactDOM.render(<App/>,div)
    })
  });

  class Checklogin {
    static work() {
      return Work();
    }
  }

  describe('login',()=>{
    it('success axios',()=>{
      axios.post.mockResolvedValueOnce({data:{email:'anton@gmail.com',password:'123'}});
      Checklogin.work().then(data => expect(data).toEqual("Success"));
    })
    it('error axios',()=>{
      axios.post.mockResolvedValueOnce({data:{email:'mark',password:'1234'}});
      Checklogin.work().then(data => expect(data).toEqual("Error"));
    })
  });


  class Checksignup {
    static work() {
      return WorkSignUp();
    }
  }

  describe('signup',()=>{

    it('success axios',()=>{
      axios.post.mockResolvedValueOnce({data:{n:'3',s:'3',u:'steve',p1:'1234',e:'2',p2:'1234'}});
      Checksignup.work().then(data => expect(data).toEqual("Success"));
    })
    it('error axios',()=>{
      axios.post.mockResolvedValueOnce({data:{n:'3',s:'3',u:'',p1:'',e:'2',p2:'1234'}});
      Checksignup.work().then(data => expect(data).toEqual("Success"));
    })
  })
  class Checkadd {
    static work() {
      return WorkAddCourse();
    }
  }
  describe('main',()=>{

    it('success axios',()=>{
      axios.post.mockResolvedValueOnce({data:{n:'maths',d:'3'}});
      Checkadd.work().then(data => expect(data).toEqual("Success"));
    })
    it('error axios',()=>{
      axios.post.mockResolvedValueOnce({data:{n:'maths',d:'3'}});
      Checkadd.work().then(data => expect(data).toEqual("Success"));
    })

});
