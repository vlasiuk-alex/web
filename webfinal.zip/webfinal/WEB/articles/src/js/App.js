import {Component} from "react";
import {BrowserRouter as Router, Switch, Route, Link} from "react-router-dom";
import RenderLogin from "./Login";
import RenderMenu from "./Menu"
import RenderSignUp from "./Sign_up";
import RendersMenu from "./about"
import FromMenu from "./article"


class App extends Component {
    render(){
        return(
            <Router>
                <div className={'video_curs'}>
                    <Switch>
                        <Route path='/' exact component={RenderLogin}/>
                        <Route path='/menu'  component={RenderMenu}/>
                        <Route path='/signup'  component={RenderSignUp}/>
                        <Route path='/about'  component={RendersMenu}/>
                        <Route path='/article'  component={FromMenu}/>
                    </Switch>
                </div>
            </Router>
        )}
}

export default App;