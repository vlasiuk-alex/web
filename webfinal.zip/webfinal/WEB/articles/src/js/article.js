import React from 'react';
import '../css/menu.css';
import {ReactSession} from 'react-client-session';
import {Link, useHistory} from "react-router-dom";
import AwesomeSlider from 'react-awesome-slider';
import 'react-awesome-slider/dist/styles.css';
import RenderLogOut from "./functions";



// async function Article() {
//
//    axios.post('http://localhost:5000/add_course', {})
//        .then(resp => {
//            if (resp.data.n === ''||resp.data.d === '') {
//                return 'Error'
//            }
//            return 'Success'
//        });
//
// }

function FromMenu()
{
    if (ReactSession.get('id'))
        return (


            <header>
                <nav>
                    <div className="area">
                        <input type="checkbox" id="check"/>
                        <label htmlFor="check" className="checkbtn">
                            <i className="fa fa-bars"></i>
                        </label>
                        <ul>
                            <li><a href="#"> <Link to='/menu'> Home </Link></a></li>
                            <li><a href="#"> <Link to='/'> Log out </Link></a></li>
                            <li><a href="#"><Link to='/'> Sign in </Link></a></li>
                        </ul>
                    </div>
                </nav>

                <main>
                    <div className="logo">
                        <h1>ALAR</h1>
                        <h2>Articles for soul</h2>
                        <h3>Article </h3>
                    </div>
                    <div className="blackline"></div>
                    <div className="block_article_info">

                        <div className="info">
                            <div className="article_title">Article</div>
                            <p>Author: 1, Published: Yesterday</p>
                            <div className="article_text">Any any any any any any any any text you want.</div>
                        </div>
                    </div>
                </main>
            </header>
        );
}

// export {
//     Article
// }

export default FromMenu;