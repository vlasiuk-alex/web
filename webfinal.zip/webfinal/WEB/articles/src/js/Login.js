import React from 'react';
import axios from "axios";
import '../css/login.css';
import {ReactSession} from 'react-client-session';
import {useHistory,Link} from "react-router-dom";


// async function Work()
// {
//    return  axios.post('/',{}).
//    then(resp => {
//        if(resp.data.username==="steve" && resp.data.password==='1234')
//            return "Success";
//        return "Error"
//    });
// }

ReactSession.setStoreType("localStorage");
function RenderLogin()
{
     const history = useHistory();
     debugger;
     function Work(event) {
         debugger;
         event.preventDefault();
         var username = document.getElementById('name').value;
         var password = document.getElementById('password').value;
         axios.post('http://localhost:5000/',
             {
                 username: username,
                 password: password
             })

             .then(resp => {
                 if (resp.data.message === 'Success') {
                     ReactSession.set('id',resp.data.id);
                     ReactSession.set('role',resp.data.role);
                     ReactSession.set('username',resp.data.username);
                     ReactSession.set('email',resp.data.email);
                     ReactSession.set('surname',resp.data.surname);

                     history.push('/menu') ;
                 }
                 else
                 {
                     document.getElementById("login").innerHTML =
                         '<h1 style="color:crimson;">'+resp.data.message+'</h1>';
                 }
             });
     }
    return (
        <div className="mains_login">
            <div className="center">
                <div id="login">
                    <h1 id="meta">Login</h1>
                </div>
                <form onSubmit={Work} className="main">
                    <div className="data">
                        <div className= "span">
                        <input type="text" id="name" placeholder=" "/>
                        <label>User name</label></div>

                    </div>
                    <div className="data">
                            <input type="password" id="password" placeholder=" "/>
                        <label>Password</label>
                    </div>
                    <input type="submit" value="Login"/>
                        <div className="signup"> First time here?<Link to='/signup'> SignUp</Link></div>
                </form>
            </div>
        </div>
    )
}

// export {
//     Work
// }

export default  RenderLogin;