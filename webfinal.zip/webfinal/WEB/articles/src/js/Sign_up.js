import React from 'react';
import axios from "axios";
import '../css/sign_up.css'
import {Link, useHistory} from "react-router-dom";
import {ReactSession} from "react-client-session";

// async function WorkSignUp() {

//    axios.post('http://localhost:5000/sign_up', {})
//        .then(resp => {
//            if (resp.data.n === ''||resp.data.s === ''||resp.data.u === ''||resp.data.p1 === ''||resp.data.p2 === ''||resp.data.e === '') {
//                return 'Error'
//            }
//            return 'Success'
//        });
// }

    function RenderSignUp() {

        const history = useHistory();

        function Work(event) {
            event.preventDefault();
            var name = document.getElementById('name').value;
            var surname = document.getElementById('surname').value;
            var username = document.getElementById('username').value;
            var password1 = document.getElementById('password1').value;
            var password2 = document.getElementById('password2').value
            var email = document.getElementById('email').value;
            axios.post('http://localhost:5000/sign_up',
                {
                    name: name,
                    surname: surname,
                    username: username,
                    password1: password1,
                    password2: password2,
                    email: email
                })
                .then(resp => {
                    if (resp.data.message === 'Success') {
                        ReactSession.set('id', resp.data.id);
                        ReactSession.set('username', username);
                        ReactSession.set('name', name);
                        ReactSession.set('email', email);
                        ReactSession.set('surname', surname);
                        history.push('/menu');
                    } else {
                        document.getElementById("message").innerHTML =
                            '<h1 style="color:gray;">' + resp.data.message + '</h1>';
                    }
                });

        }

        return (
            <div className="mains_sign">
                <div className="center">
                    <div id="message">
                        <h1>Register</h1>
                    </div>
                    <form>
                        <div className="data">
                            <input type="text" id="name" placeholder=" "/>
                            <label>Name</label>
                        </div>
                        <div className="data">
                            <input type="text" id="surname" placeholder=" "/>
                            <label>Surname</label>
                        </div>
                        <div className="data">
                            <input type="text" id="username" placeholder=" "/>
                            <label>User name</label>
                        </div>
                        <div className="data">
                            <input type="password" id="password1" placeholder=" "/>
                            <label>Password</label>
                        </div>
                        <div className="data">
                            <input type="password" id="password2" placeholder=" "/>
                            <label>Repeat password</label>
                        </div>
                        <div className="data">
                            <input type="text" id="email" placeholder=" "/>
                            <label>Enter email</label>
                        </div>
                        <div className="button">
                            <input onClick={Work} type="submit" value="Register"/>
                            <Link to='/'>
                                <button>Cancel</button>
                            </Link>
                        </div>
                    </form>
                </div>
            </div>
        );
    }

// export {
//     WorkSignUp
// }

export default  RenderSignUp;
