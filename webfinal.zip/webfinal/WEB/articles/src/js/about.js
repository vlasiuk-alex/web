import React from 'react';
import '../css/menu.css';
import {ReactSession} from 'react-client-session';
import {Link, useHistory} from "react-router-dom";
import AwesomeSlider from 'react-awesome-slider';
import 'react-awesome-slider/dist/styles.css';
import RenderLogOut from "./functions";



// async function About() {
//
//    axios.post('http://localhost:5000/add_course', {})
//        .then(resp => {
//            if (resp.data.n === ''||resp.data.d === '') {
//                return 'Error'
//            }
//            return 'Success'
//        });
//
// }

function RendersMenu()
{
    if (ReactSession.get('id'))
        return (


            <header>
                <nav>
                    <div className="area">
                        <input type="checkbox" id="check"/>
                        <label htmlFor="check" className="checkbtn">
                            <i className="fa fa-bars"></i>
                        </label>
                        <ul>
                            <li><a href="#"> <Link to='/menu'> Home </Link></a></li>
                            <li><a href="#"> <Link to='/'> Log out </Link></a></li>
                            <li><a href="#"><Link to='/'> Sign in </Link></a></li>
                        </ul>
                    </div>
                </nav>

                <main>
                    <div className="logo">
                        <h1>ALAR</h1>
                        <h2>Articles for soul</h2>
                    </div>
                    <div className="blackline"></div>
                    <div className="text-about-us">
                        <h1>About us</h1>
                        <p>ALAR is a platform which helps you to spend free time with cup of coffee reading articles.
                            Search for something interesting.
                        </p>
                    </div>
                </main>
            </header>
        );
}

// export {
//     About
// }

export default RendersMenu;