import React from 'react'
import axios from "axios";
import {ReactSession} from "react-client-session";
import {useHistory} from "react-router-dom";
ReactSession.setStoreType("localStorage");

function func(id)
{
    const x = document.getElementById(id);
    if(x.style.display === "block")
        x.style.display = "none";
    else
        x.style.display = "block";
}
function Show_Fields(event)
{
    event.preventDefault();
    const x = document.getElementById("field");
    const y = document.getElementById("confirm");
    document.getElementById("check_password").value='';
    x.style.display = "none";
    y.style.display = "block";

}
function ShowAccess(event)
{
    event.preventDefault();
    const x = document.getElementById("field");
    const y = document.getElementById("confirm");
    document.getElementById("check_password").value='';
    y.style.display = "none";
    x.style.display = "block";
}
function ShowManageAccount(event)
{
    event.preventDefault();
    func('back');
    func('ManageUser');
    Show_Fields(event);
}

function CheckPassword(event)
{
    event.preventDefault();
    var check=document.getElementById('check_password').value;
    axios('http://localhost:5000/user',{
            method:'POST',
            credentials: "include",
            headers:{
                'Access-Control-Allow-Origin': '*',
                'Content-Type': 'application/json',
                withCredentials: true,
                mode: 'no-cors',
            },
            data: {
                check:check,
                id:ReactSession.get('id')
            }
        }
    )
        .then(resp => {
            if (resp.data.message==='Success'){
                ShowAccess(event);
                document.getElementById("username").value=resp.data.username;
                document.getElementById("user_name").value=resp.data.name;
                document.getElementById("surname").value=resp.data.surname;
                document.getElementById("email").value=resp.data.email;
                document.getElementById("message").innerHTML ='<h1>Update User Data</h1>';
            }
            else
                document.getElementById("message").innerHTML ='<h1 style="color:crimson;">Access denied</h1>';
        });
}




function  check()
{
    var x = document.getElementById('admin');
    if(ReactSession.get('role')==='admin'){

        if (x.style.display === 'none')
            x.style.display = 'block';
    }
    else
        x.style.display = 'none';
}


function ShowDeleteAccount(event)
{
    event.preventDefault();
    func('back');
    var x = document.getElementById('DeleteAccount');
    if (x.style.display === 'none')
        x.style.display = 'block';
    else
        x.style.display = 'none';
}



function RenderLogOut()
{
    const history = useHistory();
    function LogOut(event)
    {
        event.preventDefault();
        ReactSession.set('id',null);
        history.push('/');
    }
    return (
        <a id="logout" onClick={LogOut}>Log Out</a>
    );
}




export {
    CheckPassword,
    ShowManageAccount,
    check,
    ShowDeleteAccount,
    //show_video,
}

export default RenderLogOut;
