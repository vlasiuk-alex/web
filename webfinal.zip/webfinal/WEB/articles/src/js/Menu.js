import React from 'react';
import '../css/menu.css';
import {ReactSession} from 'react-client-session';
import {Link, useHistory} from "react-router-dom";
import AwesomeSlider from 'react-awesome-slider';
import 'react-awesome-slider/dist/styles.css';
import RenderLogOut from "./functions";



// async function WorkAddCourse() {
//
//    axios.post('http://localhost:5000/add_course', {})
//        .then(resp => {
//            if (resp.data.n === ''||resp.data.d === '') {
//                return 'Error'
//            }
//            return 'Success'
//        });
//
// }

function RenderMenu()
{
    if (ReactSession.get('id'))
    return (


        <header>
            <nav>
                <div className="area">
                    <input type="checkbox" id="check"/>
                        <label htmlFor="check" className="checkbtn">
                            <i className="fa fa-bars"></i>
                        </label>
                        <ul>
                            <li><a href="#"> <Link to='/'> Log out </Link></a></li>
                            <li><a href="#"><Link to='/'> Sign in </Link></a></li>
                            <li><a href="#"><Link to='/about'> About Us </Link></a></li>
                        </ul>
                </div>
            </nav>

    <main>
        <div className="logo">
            <h1>ALAR</h1>
            <h2>Articles for soul</h2>
        </div>
        <div className="blackline"></div>
        <div className="main-container clearfix">
            <div className="sidebar">
            </div>
            <div className="article-list">
                <div className="article">
                        <div className="article-preview">
                            <h1><a href="#">Article #1</a></h1>
                            <p>Author: 1, Published: Yesterday</p>
                            <p className="preview-text">Space is a cool thing.</p>
                            <li><a href="#" className="preview-btn view-article"><Link to='/article'> View article </Link></a></li>
                        </div>
                </div>
                <div className="blackline"></div>
                <div className="article">
                        <div className="article-preview">
                            <h1><a href="#">Article #2</a></h1>
                            <p>Author Alex Alexeev, Published: 21-07-2020</p>
                            <p className="preview-text">Bla Bla Bla ekology ekology.</p>
                            <li><a href="#" className="preview-btn view-article"><Link to='/article'> View article </Link></a></li>
                        </div>
                </div>
                <div className="blackline"></div>
                <div className="article">
                        <div className="article-preview">
                            <h1><a href="#">Article #3</a></h1>
                            <p>Author: joe Cocker, Published: Yesterday</p>
                            <p className="preview-text">Why your car eats a lot?.</p>
                            <li><a href="#" className="preview-btn view-article"><Link to='/article'> View article </Link></a></li>
                        </div>
                </div>
                <div className="blackline"></div>
            </div>
        </div>
    </main>
        </header>
    );
}

// export {
//     WorkAddCourse
// }

export default RenderMenu;
